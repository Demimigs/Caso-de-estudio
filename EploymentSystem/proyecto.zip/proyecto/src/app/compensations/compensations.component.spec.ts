import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompensationsComponent } from './compensations.component';

describe('CompensationsComponent', () => {
  let component: CompensationsComponent;
  let fixture: ComponentFixture<CompensationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompensationsComponent ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompensationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('shouldcreate', () => {
    expect(component).toBeTruthy();
  });
});

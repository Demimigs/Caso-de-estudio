export default class Compensation {

    type?: string;
    amount?: number;
    description?: string;
    year?: number;
    month?: number;
    
  }
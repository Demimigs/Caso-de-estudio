import Compensation from './compensation';

export default class Employee {

  id?: number;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  birthDate?: string;
  position?: string;
  compesationList?: Compensation[];
  
}
